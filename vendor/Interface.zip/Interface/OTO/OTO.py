import os
from ctypes import *
from flask import Flask, jsonify, request

# DLL 路径
DLL_PATH = os.path.abspath(os.path.join("DLL_x86", "UserApplication.dll"))
print(f"[INFO] Loading DLL from {DLL_PATH}")

OTOdll = CDLL(DLL_PATH)

# 设置函数参数和返回值类型（示例，需根据 DLL 文档确认）
OTOdll.UAI_SpectrometerGetDeviceAmount.argtypes = [c_int, c_int, POINTER(c_int)]
OTOdll.UAI_SpectrometerGetDeviceAmount.restype = c_int

OTOdll.UAI_SpectrometerOpen.argtypes = [c_int, POINTER(c_int), c_int, c_int]
OTOdll.UAI_SpectrometerOpen.restype = c_int

OTOdll.UAI_SpectromoduleGetFrameSize.argtypes = [c_int, POINTER(c_int)]
OTOdll.UAI_SpectromoduleGetFrameSize.restype = c_int

OTOdll.UAI_SpectrometerWavelengthAcquire.argtypes = [c_int, POINTER(c_float)]
OTOdll.UAI_SpectrometerWavelengthAcquire.restype = c_int

OTOdll.UAI_SpectrometerDataAcquire.argtypes = [c_int, c_int, POINTER(c_float), c_int]
OTOdll.UAI_SpectrometerDataAcquire.restype = c_int

OTOdll.UAI_SpectrometerGetModelName.argtypes = [c_int, c_void_p]
OTOdll.UAI_SpectrometerGetModelName.restype = c_int

VID = 1592
PID = 2732

def initialize_device():
    intDeviceAmount = c_int(0)
    err = OTOdll.UAI_SpectrometerGetDeviceAmount(VID, PID, byref(intDeviceAmount))
    print(f"[DEBUG] Device amount = {intDeviceAmount.value}, err = {err}")

    if intDeviceAmount.value < 1:
        raise RuntimeError("No spectrometer connected")

    device_handle = c_int(0)
    err = OTOdll.UAI_SpectrometerOpen(0, byref(device_handle), VID, PID)
    print(f"[DEBUG] Device handle = {device_handle.value}, err = {err}")
    if device_handle.value == 0:
        raise RuntimeError("Failed to open device")
    return device_handle.value

device_handle = initialize_device()

def get_frame_size(handle):
    frame_size = c_int(0)
    err = OTOdll.UAI_SpectromoduleGetFrameSize(handle, byref(frame_size))
    if err != 0:
        raise RuntimeError("Failed to get frame size")
    return frame_size.value

def fetch_wavelength_array(handle):
    channels = get_frame_size(handle)
    buffer = (c_float * channels)()
    ret = OTOdll.UAI_SpectrometerWavelengthAcquire(handle, buffer)
    if ret != 0:
        raise RuntimeError("Failed to acquire wavelength")
    return list(buffer)

def fetch_intensity_array(handle, integration_time_us=100000, average=1):
    channels = get_frame_size(handle)
    buffer = (c_float * channels)()
    ret = OTOdll.UAI_SpectrometerDataAcquire(handle, integration_time_us, buffer, average)
    if ret != 0:
        raise RuntimeError(f"Data acquire failed, code={ret}")
    return list(buffer)

buf = create_string_buffer(256)
err = OTOdll.UAI_SpectrometerGetModelName(device_handle, buf)
model_name = buf.value.decode(errors='ignore')

app = Flask(__name__)

@app.route("/info")
def info():
    print(f"[DEBUG] Device handle in /info: {device_handle}")
    try:
        buf = create_string_buffer(256)
        err = OTOdll.UAI_SpectrometerGetModelName(device_handle, buf)
        print(f"[DEBUG] UAI_SpectrometerGetModelName err = {err}, buffer address = {addressof(buf)}")
        if err != 0:
            return jsonify({"status": "error", "message": f"Failed to get model name, err={err}"}), 500
        model_name = buf.value.decode(errors='ignore')
        return jsonify({"status": "ok", "model_name": model_name})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/wavelengths")
def wavelengths_route():
    try:
        lambdas = fetch_wavelength_array(device_handle)
        return jsonify({"status": "ok", "wavelengths": lambdas})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/spectrum")
def spectrum_route():
    try:
        integration_time = int(request.args.get("integration_time_us", 100000))
        average = int(request.args.get("average", 1))
        lambdas = fetch_wavelength_array(device_handle)
        intensities = fetch_intensity_array(device_handle, integration_time, average)
        data = [{wl: inten} for wl, inten in zip(lambdas, intensities)]
        return jsonify({"status": "ok", "spectrum": data})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9000)
